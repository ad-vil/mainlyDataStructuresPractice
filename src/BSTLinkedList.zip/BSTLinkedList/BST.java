package Problem2;

// class for implementing methods for BST

public class BST {
    private BSTNode root;

    // constructor
    public BST() {
        root = null;
    }

    // recursive method to insert a word and its meaning
    public void insert(String word, String meaning) {
        root = insertHelper(root, word, meaning);
    }

    // helper method for insertion because i love recursion now
    private BSTNode insertHelper(BSTNode root, String word, String meaning) {
        if (root == null) {
            return new BSTNode(word, meaning);
        }

        int compareTo = word.compareTo(root.word);

        if (compareTo < 0) {
            root.left = insertHelper(root.left, word, meaning);
        }
        else {
            root.right = insertHelper(root.right, word, meaning);
        }

        return root;
    }

    // method to find for a specific word
    public BSTNode find(String word) {
        return findHelper(root, word);
    }

    // helper method for finding
    private BSTNode findHelper(BSTNode root, String word) {
        if (root == null || root.word.equalsIgnoreCase(word)) {
            return root;
        }

        int compareTo = word.compareTo(root.word);

        if (compareTo < 0) {
            return findHelper(root.left, word);
        }

        return findHelper(root.right, word);
    }

    // method for in-order traversal
    public void traverse() {
        traverseHelper(root);
    }

    // helper  for traversal
    private void traverseHelper(BSTNode root) {
        if (root != null) {
            traverseHelper(root.left);
            System.out.println(root.word + ": " + root.definition);
            traverseHelper(root.right);
        }
    }
    // method to delete a specific word
    public void delete(String word) {
        root = deleteHelper(root, word);
    }

    // helper method for deleting
    private BSTNode deleteHelper(BSTNode root, String word) {
        if (root == null) {
            return root;
        }

        int compareTo = word.compareTo(root.word);

        if (compareTo < 0) {
            root.left = deleteHelper(root.left, word);
        }
        else if (compareTo > 0) {
            root.right = deleteHelper(root.right, word);
        }
        else {
            if (root.left == null) {
                return root.right;
            }
            else if (root.right == null) {
                return root.left;
            }

            root.word = minValue(root.right);
            root.right = deleteHelper(root.right, root.word);
        }

        return root;
    }

    // method for finding minValue (in this case min word) for deletion
    private String minValue(BSTNode root) {
        String minValue = root.word;
        while (root.left != null) {
            minValue = root.left.word;
            root = root.left;
        }
        return minValue;
    }

}
