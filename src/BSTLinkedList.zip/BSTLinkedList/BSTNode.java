package Problem2;

// class for creating nodes in the Binary Search Tree

public class BSTNode {
    String word;
    String definition;
    BSTNode left;
    BSTNode right;
    LLNode linkedListHead; // head of the linked list for additional meanings

    public BSTNode(String word, String definition) {
        this.word = word;
        this.definition = definition;
        this.left = null;
        this.right = null;
        this.linkedListHead = null;
    }

    // cool lil method that allows the user to add their own meanings to a word
    public void addMeaning(String newMeaning) {
        LLNode newNode = new LLNode(newMeaning);
        if (linkedListHead == null) {
            linkedListHead = newNode;
        }
        else {
            LLNode current = linkedListHead;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // this prints all the meanings (including the added ones) of the word
    public void printMeanings() {
        System.out.println("word you added a new meaning to: " + word);
        System.out.println("original definition: " + definition);

        LLNode current = linkedListHead;
        while (current != null) {
            System.out.println("additional meaning: " + current.meaning);
            current = current.next;
        }
    }
}
