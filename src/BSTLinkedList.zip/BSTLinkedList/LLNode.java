package Problem2;

// class for the linked list nodes

public class LLNode {
    String meaning;
    LLNode next;

    public LLNode(String meaning) {
        this.meaning = meaning;
        this.next = null;
    }
}
