package Problem2;

import java.io.*;

public class Main {
    public static void main(String[] args) {
        BST dictionary = new BST();

        try (BufferedReader br = new BufferedReader(new FileReader("Dictionary.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                // cleanup to make sure there's no weird extra spaces or anything
                line = line.trim();

                // checks if line is empty
                if (line.isEmpty()) {
                    continue;
                }

                // splitting at the first present space of each line
                int splitIndex = line.indexOf(' ');
                if (splitIndex != -1) { //for space detected
                    String word = line.substring(0, splitIndex); // eextracting word from start of line until the splitIndex
                    String definition = line.substring(splitIndex + 1); // definition is the rest of the line
                    dictionary.insert(word, definition);
                }
                else { // in case some lines just don't have words
                    System.out.println("Line does not contain a word and definition: " + line);
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        /* traverse to make sure i actually did something and it doesn't just print this like it did for 2 hours lol
        Line does not contain a word and definition
        Line does not contain a word and definition
        Line does not contain a word and definition
        Line does not contain a word and definition
        Line does not contain a word and definition
         */

        dictionary.traverse();
        // yay it works!!!


        // testing out the find methods:
        BSTNode result = dictionary.find("Able");
        if (result != null) {
            System.out.println("Word: " + result.word);
            System.out.println("Definition: " + result.definition);
        }
        else {
            System.out.println("Word not found.");
        }
        BSTNode result2 = dictionary.find("Gearbox");
        if (result2 != null) {
            System.out.println("Word: " + result2.word);
            System.out.println("Definition: " + result2.definition);
        }
        else {
            System.out.println("Word not found.");
        }
        BSTNode result3 = dictionary.find("Amongus");
        if (result3 != null) {
            System.out.println("Word: " + result3.word);
            System.out.println("Definition: " + result3.definition);
        }
        else {
            System.out.println("Word not found.");
        }
        BSTNode result4 = dictionary.find("Zygote");
        if (result4 != null) {
            System.out.println("Word: " + result4.word);
            System.out.println("Definition: " + result4.definition);
        }
        else {
            System.out.println("Word not found.");
        }
        BSTNode result5 = dictionary.find("instalockJett");
        if (result5 != null) {
            System.out.println("Word: " + result5.word);
            System.out.println("Definition: " + result5.definition);
        }
        else {
            System.out.println("Word not found.");
        }

        //testing out the add meanings and printMeanings that allow the user to add new methods to the word
        BSTNode wordNode = dictionary.find("Gearbox");
        if (wordNode != null) {
            wordNode.addMeaning("car go neyowwwww.");
            // car officially goes neyowwww
            wordNode.printMeanings();
        }
        else {
            System.out.println("Word not found.");
        }
    }
}
