package factoryPattern;

public interface Car {
    void assemble();
}
