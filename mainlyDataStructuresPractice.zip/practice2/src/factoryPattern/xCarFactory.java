package factoryPattern;

public interface xCarFactory {
    Car createCar(String type);
}
