package stuff1;

public class employee {

}